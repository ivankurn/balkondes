<?php

return [
	'reset_password'		=> 'Reset Password',
	'enter_reset_password'	=> 'Enter new password below:',
	'submit'				=> 'Submit'
];
?>