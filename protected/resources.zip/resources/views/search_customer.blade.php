<div class="form-group">
	<label class="col-md-3 control-label">Search_customer</label>
	<div class="col-md-9">
		<div class="input-group">
			<span class="input-group-addon" id="sizing-addon1">Rp.</span>
			<input class="form-control" type="text" name="harga_eceran" value="{{ old('harga_eceran') }}">
		</div>
	</div>
</div>
