<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="utf-8" />
		<title>Taman Wisata Candi Borobudur</title>
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<meta content="" name="description" />
		<meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/simple-line-icons/simple-line-icons.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/uniform/css/uniform.default.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css') }}" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
		<link href="{{ URL::to('assets/global/plugins/morris/morris.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/global/plugins/mapplic/mapplic/mapplic.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ asset('assets/global/plugins/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ asset('assets/global/plugins/select2/css/select2-bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ asset('assets/global/plugins/datatables/datatables.min.css') }}" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
		<link href="{{ URL::to('assets/global/css/components.min.css') }}" rel="stylesheet" id="style_components" type="text/css" />
		<link href="{{ URL::to('assets/global/css/plugins.min.css') }}" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
		<link href="{{ URL::to('assets/layouts/layout7/css/layout.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ URL::to('assets/layouts/layout7/css/custom.min.css') }}" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-md">
        <!-- BEGIN HEADER -->
        <div class="page-header navbar-fixed-top">
            <!-- BEGIN HEADER INNER -->
            <div class="clearfix">
                <!-- BEGIN BURGER TRIGGER -->
                <div class="burger-trigger">
                    <button class="menu-trigger">
                        <img src="{{ URL::to('assets/layouts/layout7/img/m_toggler.png') }}" alt=""> </button>
                    <div class="menu-overlay menu-overlay-bg-transparent">
                        <div class="menu-overlay-content">
                            <ul class="menu-overlay-nav text-uppercase">
                                <li>
                                   <a href="{{URL::to('/')}}">Registrasi</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="menu-bg-overlay">
                        <button class="menu-close">&times;</button>
                    </div>
                    <!-- the overlay element -->
                </div>
                <!-- END NAV TRIGGER -->
                <!-- BEGIN LOGO -->
                <div class="page-logo">
                    <a href="{{ URL::to('/')}}">
						<img src="{{ URL::to('assets/layouts/layout7/img/logo-big-green.png') }}" alt="" style="height: 50px !important;"></a>
                </div>
                <!-- END LOGO -->
                <!-- BEGIN TOP NAVIGATION MENU -->
                <div class="top-menu">
                </div>
                <!-- END TOP NAVIGATION MENU -->
            </div>
            <!-- END HEADER INNER -->
        </div>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container page-content-inner page-container-bg-solid">
            <!-- BEGIN CONTENT -->
           <div class="row">
            <div class="col-md-12">
                <div class="portlet light portlet-fit bordered">
					<div class="portlet-title">
					   <div class="caption">
						   <i class="fa fa-search"></i>
						   <span class="caption-subject bold uppercase font-green">Form Registrasi</span>
					   </div>
				   </div>
					<div class="portlet-body">
						<div class="portlet-body form">
							<form action="" class="form-horizontal" method="POST">
							<div class="form-body">
							    <div class="form-group">
								   <label class="col-md-3 control-label">Nama</label>
								   <div class="input-group select2-bootstrap-prepend col-md-7">
									   <div class="form-group row">
										   <div class="col-md-6">
											   <input type="text" class="form-control" placeholder="Nama" name="nama" id="nama" required>
										   </div>
									   </div>
								   </div>
							   </div>
							   <div class="form-group">
								   <label class="col-md-3 control-label">Phone</label>
								   <div class="input-group select2-bootstrap-prepend col-md-7">
									   <div class="form-group row">
										   <div class="col-md-6">
											   <input type="text" class="form-control" placeholder="No Telpon" name="phone" id="phone" required>
										   </div>
									   </div>
								   </div>
							   </div>
						   </div>
						   <div class="form-actions">
							   <div class="row">
								   <div class="col-md-offset-3 col-md-4">
									   <button type="submit" class="btn green" id="submitCari"><i class="fa fa-search"></i> Pesan Sekarang!</button> 
									   <input type="hidden" name="_token" value="{{ csrf_token() }}">
								   </div>
							   </div>
						   </div>
						  </form>
						</div>
					</div>
                </div>
			</div>
        </div>
    
        </div>
            <!-- END CONTENT -->
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN QUICK SIDEBAR -->
        <!-- END QUICK SIDEBAR -->
        <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="go2top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->
        <!-- BEGIN QUICK NAV -->
        <!-- END QUICK NAV -->
        <!-- BEGIN CORE PLUGINS -->
		<script src="{{ asset('assets/global/plugins/jquery.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/js.cookie.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/jquery.blockui.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js') }}" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
		<script src="{{ asset('assets/global/plugins/morris/morris.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/morris/raphael-min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/mapplic/js/hammer.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/mapplic/js/jquery.easing.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/mapplic/js/jquery.mousewheel.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/mapplic/mapplic/mapplic.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/counterup/jquery.waypoints.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/jquery.sparkline.min.js') }}" type="text/javascript"></script>
		
		<script src="{{ asset('assets/global/plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/scripts/datatable.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/datatables/datatables.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js') }}" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
		<script src="{{ asset('assets/global/scripts/app.min.js') }}" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
		<script src="{{ asset('assets/pages/scripts/dashboard.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/pages/scripts/components-select2.min.js') }}" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
		<script src="{{ asset('assets/layouts/layout7/scripts/layout.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/layouts/global/scripts/quick-sidebar.min.js') }}" type="text/javascript"></script>
		<script src="{{ asset('assets/layouts/global/scripts/quick-nav.js') }}" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>