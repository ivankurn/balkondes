@extends('body')

@section('content')
  <div class="page-bar">
      <ul class="page-breadcrumb">
          <li>
              <a href="index.html">Home</a>
              <i class="fa fa-circle"></i>
          </li>
          <li>
              <span>Page Layouts</span>
          </li>
      </ul>
  </div>

  <h1 class="page-title"> Boxed Page Layout
  <small>boxed page layout</small>
  </h1>

  <div class="note note-info">
    <p> Boxed page layout. </p>
  </div>
@endsection
